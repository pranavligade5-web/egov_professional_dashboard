from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path
import numpy as np

from recommender import EGovernanceRecommender
from fuzzification import FuzzyPreprocessor

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "egov.db"

app = Flask(__name__)
app.secret_key = "egov-demo-secret-2026"


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        age INTEGER NOT NULL,
        occupation INTEGER NOT NULL,
        category INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS schemes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        eligibility TEXT NOT NULL,
        rating REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        scheme_id INTEGER NOT NULL,
        rating REAL NOT NULL,
        UNIQUE(user_id, scheme_id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(scheme_id) REFERENCES schemes(id)
    );

    CREATE TABLE IF NOT EXISTS recommendations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        scheme_id INTEGER NOT NULL,
        score REAL NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(scheme_id) REFERENCES schemes(id)
    );
    """)

    if conn.execute("SELECT COUNT(*) FROM schemes").fetchone()[0] == 0:
        schemes = [
            ("Digital India Services", "Digital Services",
             "Digital public services and online government access.",
             "Open to citizens seeking digital government services.", 4.6),
            ("Education Scholarship", "Education",
             "Scholarship and education-support opportunities.",
             "Students and eligible learners.", 4.8),
            ("Healthcare Assistance", "Healthcare",
             "Government healthcare assistance and support.",
             "Citizens requiring eligible healthcare support.", 4.7),
            ("Senior Citizen Services", "Senior Citizens",
             "Government services designed for senior citizens.",
             "Senior citizens and eligible dependants.", 4.5),
        ]
        conn.executemany(
            "INSERT INTO schemes(name,category,description,eligibility,rating) VALUES(?,?,?,?,?)",
            schemes
        )

    # Demo accounts / rating data.
    demo_users = [
        ("Demo Student 1", "student1@example.com", 22, 1, 0),
        ("Active Citizen", "citizen@example.com", 25, 1, 0),
        ("Demo Businessman 1", "business1@example.com", 45, 2, 1),
        ("Demo Businessman 2", "business2@example.com", 50, 2, 1),
        ("Demo Student 2", "student2@example.com", 21, 1, 0),
    ]
    for name, email, age, occupation, category in demo_users:
        if conn.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone() is None:
            conn.execute(
                "INSERT INTO users(name,email,password_hash,age,occupation,category) VALUES(?,?,?,?,?,?)",
                (name, email, generate_password_hash("demo123"), age, occupation, category)
            )

    if conn.execute("SELECT COUNT(*) FROM ratings").fetchone()[0] == 0:
        user_ids = {
            row["email"]: row["id"]
            for row in conn.execute("SELECT id,email FROM users").fetchall()
        }
        ratings = [
            ("student1@example.com", [5, 3, None, 1]),
            ("citizen@example.com", [4, None, None, 1]),
            ("business1@example.com", [1, 5, 4, None]),
            ("business2@example.com", [2, 4, 5, None]),
            ("student2@example.com", [4.5, 3.5, None, 1]),
        ]
        for email, values in ratings:
            for scheme_id, value in enumerate(values, 1):
                if value is not None:
                    conn.execute(
                        "INSERT OR IGNORE INTO ratings(user_id,scheme_id,rating) VALUES(?,?,?)",
                        (user_ids[email], scheme_id, value)
                    )

    conn.commit()
    conn.close()


def logged_user():
    if "user_id" not in session:
        return None
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return user


def recommendation_for(user):
    conn = db()
    users = conn.execute(
        "SELECT id,age,occupation,category,name FROM users ORDER BY id"
    ).fetchall()
    schemes = conn.execute("SELECT * FROM schemes ORDER BY id").fetchall()
    rating_rows = conn.execute(
        "SELECT user_id,scheme_id,rating FROM ratings ORDER BY user_id,scheme_id"
    ).fetchall()
    conn.close()

    if len(users) < 2:
        return {"recommendations": [], "fuzzy_age": {}, "cluster": 1, "members": []}

    user_index = {row["id"]: i for i, row in enumerate(users)}
    matrix = np.full((len(users), len(schemes)), np.nan)
    for r in rating_rows:
        if r["user_id"] in user_index:
            matrix[user_index[r["user_id"]], r["scheme_id"] - 1] = r["rating"]

    active_index = user_index[user["id"]]
    features = np.array(
        [[u["age"], u["occupation"], u["category"]] for u in users],
        dtype=float
    )

    n_clusters = min(2, len(users))
    recommender = EGovernanceRecommender(n_clusters=n_clusters)
    labels = recommender.fit_clusters(features)
    predictions = recommender.predict_recommendations(
        active_user_id=active_index, ratings_matrix=matrix, top_k=3
    )

    fuzzy = FuzzyPreprocessor.fuzzify_age(user["age"])
    scheme_map = {s["id"]: s for s in schemes}
    recommendations = []
    for scheme_id, score in predictions:
        s = scheme_map[int(scheme_id) + 1] if int(scheme_id) + 1 in scheme_map else None
        if s:
            recommendations.append({
                "id": s["id"],
                "name": s["name"],
                "category": s["category"],
                "description": s["description"],
                "eligibility": s["eligibility"],
                "score": round(float(np.clip(score, 0, 5)), 2),
                "rating": s["rating"],
            })

    cluster = int(labels[active_index]) + 1
    members = [u["name"] for i, u in enumerate(users) if int(labels[i]) + 1 == cluster]

    return {
        "recommendations": recommendations,
        "fuzzy_age": {
            "Young": round(float(fuzzy[0]), 3),
            "Middle-aged": round(float(fuzzy[1]), 3),
            "Old": round(float(fuzzy[2]), 3),
        },
        "cluster": cluster,
        "members": members,
    }


@app.context_processor
def inject_user():
    return {"current_user": logged_user()}


@app.route("/")
def home():
    return redirect(url_for("dashboard")) if logged_user() else redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        try:
            name = request.form["name"].strip()
            email = request.form["email"].strip().lower()
            password = request.form["password"]
            age = int(request.form["age"])
            occupation = int(request.form["occupation"])
            category = int(request.form["category"])
            if not name or len(password) < 6 or not 18 <= age <= 100:
                raise ValueError
            conn = db()
            conn.execute(
                "INSERT INTO users(name,email,password_hash,age,occupation,category) VALUES(?,?,?,?,?,?)",
                (name, email, generate_password_hash(password), age, occupation, category)
            )
            conn.commit()
            user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            conn.close()
            session["user_id"] = user["id"]
            return redirect(url_for("dashboard"))
        except (ValueError, KeyError, sqlite3.IntegrityError):
            flash("Please enter valid details. Email may already be registered.", "error")
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
def dashboard():
    user = logged_user()
    if not user:
        return redirect(url_for("login"))
    result = recommendation_for(user)
    conn = db()
    scheme_count = conn.execute("SELECT COUNT(*) FROM schemes").fetchone()[0]
    rating_count = conn.execute("SELECT COUNT(*) FROM ratings").fetchone()[0]
    user_count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    conn.close()
    return render_template(
        "dashboard.html", result=result, stats={
            "schemes": scheme_count, "ratings": rating_count, "users": user_count
        }
    )


@app.post("/api/recommend")
def api_recommend():
    user = logged_user()
    if not user:
        return jsonify({"error": "Please log in first."}), 401
    return jsonify(recommendation_for(user))


@app.route("/schemes")
def schemes():
    if not logged_user():
        return redirect(url_for("login"))
    conn = db()
    rows = conn.execute("SELECT * FROM schemes ORDER BY rating DESC").fetchall()
    conn.close()
    return render_template("schemes.html", schemes=rows)


@app.route("/profile", methods=["GET", "POST"])
def profile():
    user = logged_user()
    if not user:
        return redirect(url_for("login"))
    if request.method == "POST":
        try:
            age = int(request.form["age"])
            occupation = int(request.form["occupation"])
            category = int(request.form["category"])
            if not 18 <= age <= 100:
                raise ValueError
            conn = db()
            conn.execute(
                "UPDATE users SET age=?,occupation=?,category=? WHERE id=?",
                (age, occupation, category, user["id"])
            )
            conn.commit()
            conn.close()
            flash("Profile updated successfully.", "success")
            return redirect(url_for("profile"))
        except (ValueError, KeyError):
            flash("Please enter valid profile information.", "error")
    return render_template("profile.html", user=user)


if __name__ == "__main__":
    app.run(debug=True)
