# Professional e-Gov Intelligence Dashboard

A Flask + SQLite application with:
- Login and registration
- Persistent SQLite database
- Citizen profiles
- Government scheme directory
- Personalized recommendations
- Fuzzy age membership analytics
- K-Means citizen clustering
- Collaborative filtering
- Responsive professional dashboard

## Run

```bash
python -m venv venv
```

Windows CMD:
```cmd
venv\Scripts\activate
```

PowerShell:
```powershell
.\venv\Scripts\Activate.ps1
```

Install:
```bash
python -m pip install -r requirements.txt
```

Start:
```bash
python app.py
```

Open:
http://127.0.0.1:5000

## Demo login

Email: citizen@example.com
Password: demo123

The SQLite database `egov.db` is created automatically on first run.

## Production note

Change `app.secret_key` in `app.py`, use a production WSGI server, and move credentials/secrets into environment variables before deployment.
