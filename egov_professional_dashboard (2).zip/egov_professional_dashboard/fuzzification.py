import numpy as np


class FuzzyPreprocessor:
    @staticmethod
    def fuzzify_age(age):
        young = 1.0 if age <= 20 else max(0.0, (35 - age) / 15.0)
        middle = max(0.0, 1.0 - abs(age - 40) / 15.0)
        old = 0.0 if age <= 45 else min(1.0, (age - 45) / 15.0)
        return np.array([young, middle, old])
