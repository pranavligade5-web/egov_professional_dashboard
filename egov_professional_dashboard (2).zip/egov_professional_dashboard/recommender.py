import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity


class EGovernanceRecommender:
    def __init__(self, n_clusters=2):
        self.n_clusters = n_clusters
        self.kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        self.cluster_labels = None

    def fit_clusters(self, background_features):
        self.cluster_labels = self.kmeans.fit_predict(background_features)
        return self.cluster_labels

    def predict_recommendations(self, active_user_id, ratings_matrix, top_k=3):
        ratings = pd.DataFrame(ratings_matrix, dtype=float)
        active = ratings.loc[active_user_id]
        similarities = cosine_similarity(ratings.fillna(0))[active_user_id].astype(float)
        similarities[active_user_id] = -1

        cluster = self.cluster_labels[active_user_id]
        candidates = [
            i for i, label in enumerate(self.cluster_labels)
            if label == cluster and i != active_user_id
        ]
        candidates.sort(key=lambda i: similarities[i], reverse=True)
        neighbors = candidates[:top_k]

        predictions = {}
        for service in active[active.isna()].index:
            numerator = denominator = 0.0
            for neighbor in neighbors:
                rating = ratings.loc[neighbor, service]
                if not pd.isna(rating):
                    sim = similarities[neighbor]
                    mean = ratings.loc[neighbor].mean()
                    numerator += sim * (rating - mean)
                    denominator += abs(sim)
            active_mean = active.mean()
            predictions[service] = (
                active_mean + numerator / denominator
                if denominator > 0 else active_mean
            )

        return sorted(predictions.items(), key=lambda x: x[1], reverse=True)
